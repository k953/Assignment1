#include <GLFW/glfw3.h>
#include <cmath>
#include <iostream>

void drawCircle(float radius) {
    glBegin(GL_LINE_LOOP);
    for (int i = 0; i < 360; ++i) {
        float theta = i * 3.14159f / 180;
        glVertex2f(radius * cos(theta), radius * sin(theta));
    }
    glEnd();
}

int main() {
    if (!glfwInit()) return -1;
    GLFWwindow* window = glfwCreateWindow(800, 600, "Mini Solar System", NULL, NULL);
    if (!window) return -1;
    glfwMakeContextCurrent(window);

    while (!glfwWindowShouldClose(window)) {
        glClear(GL_COLOR_BUFFER_BIT);
        glLoadIdentity();

        float time = glfwGetTime();
        float angle1 = time;
        float angle2 = time * 0.5f;

        // Sun
        glColor3f(1.0f, 1.0f, 0.0f);
        drawCircle(0.1f);

        // Planet 1
        glPushMatrix();
        glRotatef(angle1 * 50, 0, 0, 1);
        glTranslatef(0.5f, 0, 0);
        glColor3f(0.0f, 0.5f, 1.0f);
        drawCircle(0.05f);
        glPopMatrix();

        // Planet 2
        glPushMatrix();
        glRotatef(angle2 * 50, 0, 0, 1);
        glTranslatef(0.8f, 0, 0);
        glColor3f(1.0f, 0.0f, 0.0f);
        drawCircle(0.07f);

        // Moon
        glPushMatrix();
        glRotatef(time * 200, 0, 0, 1);
        glTranslatef(0.15f, 0, 0);
        glColor3f(0.8f, 0.8f, 0.8f);
        drawCircle(0.02f);
        glPopMatrix();

        glPopMatrix();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwTerminate();
    return 0;
}
